"""
evaluate.py - Shared evaluation script (Data Analytics & Machine Learning mini-project, Part E)

INPUT (scores/ folder): CSV files exported by the model notebooks
    scores_<model>_validation.csv             scores_<model>_test.csv                (duration EXCLUDED)
    scores_<model>_duration_validation.csv    scores_<model>_duration_test.csv       (duration INCLUDED)
Each file has two columns: y_true, score.   Model names used: logreg, tree, rf, adaboost, svm, knn
Optional: scores/fit_times.csv  (columns: model,variant,fit_time_s ; variant = no_duration / with_duration)

USAGE
    python3 evaluate.py                       # real score files (scores/ folder)
    python3 evaluate.py --demo                # pipeline test on synthetic data
    python3 evaluate.py --scores_dir scores_random --out_dir results_random   # another data split

RULES
- The decision threshold is chosen on validation (maximum F1) and applied unchanged on test, for every model.
- ROC-AUC, PR-AUC and lift only depend on the ranking of the scores (not on their scale),
  so any score works (e.g. the SVM decision_function).
- All files must share the same y_true columns (same split); otherwise the script stops with an error.

OUTPUT (results/): results_table.csv (with 95% bootstrap CIs), budget_table.csv, baselines.csv,
                   curves_<variant>.png, confusion_<variant>.png, duration_effect.png
"""
import argparse
import glob
import os
import re

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score, average_precision_score, confusion_matrix, f1_score,
    precision_recall_curve, precision_score, recall_score, roc_auc_score, roc_curve,
)

VARIANTS = ["no_duration", "with_duration"]
VARIANT_LABEL = {"no_duration": "Without duration (realistic)", "with_duration": "With duration (leakage)"}
FILE_PATTERN = re.compile(r"^scores_(?P<model>.+?)(?P<dur>_duration)?_(?P<split>validation|test)\.csv$")


# ----------------------------------------------------------------------------
# Metrics
# ----------------------------------------------------------------------------
def best_threshold(y_val, p_val):
    prec, rec, thr = precision_recall_curve(y_val, p_val)
    f1 = 2 * prec * rec / (prec + rec + 1e-12)
    return float(thr[np.argmax(f1[:-1])])


def top_frac(y, p, frac=0.10):
    k = max(1, int(len(y) * frac))
    return np.argsort(-p)[:k]


def cumulative_gain(y, p):
    order = np.argsort(-p)
    return np.arange(1, len(y) + 1) / len(y), np.cumsum(y[order]) / y.sum()


def evaluate_one(model, variant, y_val, y_test, pred):
    p_val, p_test = pred["p_val"], pred["p_test"]
    t = best_threshold(y_val, p_val)
    yhat = (p_test >= t).astype(int)
    top = top_frac(y_test, p_test, 0.10)
    (r_lo, r_hi), (p_lo, p_hi) = bootstrap_ci(y_test, p_test)
    return {
        "model": model, "variant": variant, "threshold": round(t, 4),
        "roc_auc": roc_auc_score(y_test, p_test),
        "roc_auc_ci_lo": r_lo, "roc_auc_ci_hi": r_hi,
        "pr_auc": average_precision_score(y_test, p_test),
        "pr_auc_ci_lo": p_lo, "pr_auc_ci_hi": p_hi,
        "pr_auc_over_base": average_precision_score(y_test, p_test) / y_test.mean(),
        "val_roc_auc": roc_auc_score(y_val, p_val),
        "val_pr_auc": average_precision_score(y_val, p_val),
        "f1": f1_score(y_test, yhat, zero_division=0),
        "precision": precision_score(y_test, yhat, zero_division=0),
        "recall": recall_score(y_test, yhat, zero_division=0),
        "accuracy": accuracy_score(y_test, yhat),
        "yes_rate@top10%": y_test[top].mean(),
        "lift@10%": y_test[top].mean() / y_test.mean(),
        "capture@10%": y_test[top].sum() / y_test.sum(),
        "fit_time_s": pred.get("fit_time", np.nan),
    }


def bootstrap_ci(y, p, n_boot=500, seed=0):
    """95% bootstrap CI for ROC-AUC and PR-AUC on the test set."""
    rng = np.random.RandomState(seed)
    roc, pr = [], []
    for _ in range(n_boot):
        idx = rng.randint(0, len(y), len(y))
        if y[idx].min() == y[idx].max():
            continue
        roc.append(roc_auc_score(y[idx], p[idx]))
        pr.append(average_precision_score(y[idx], p[idx]))
    q = lambda a: (float(np.percentile(a, 2.5)), float(np.percentile(a, 97.5)))
    return q(roc), q(pr)


def budget_table(preds, y_test, fracs=(0.10, 0.20, 0.30)):
    """Threshold-free view: call the top x% clients ranked by score."""
    rows = []
    for (model, variant), pr in preds.items():
        for f in fracs:
            top = top_frac(y_test, pr["p_test"], f)
            rows.append({"model": model, "variant": variant, "called_fraction": f,
                         "precision": y_test[top].mean(),
                         "recall(capture)": y_test[top].sum() / y_test.sum(),
                         "lift": y_test[top].mean() / y_test.mean()})
    return pd.DataFrame(rows)


def baseline_table(y_test, seed=0):
    base = y_test.mean()
    rng = np.random.RandomState(seed)
    rnd = rng.rand(len(y_test))
    p_yes = base
    f1_yes = 2 * p_yes / (p_yes + 1)
    return pd.DataFrame([
        {"baseline": "always 'no'", "roc_auc": 0.5, "pr_auc": base, "f1": 0.0,
         "precision": 0.0, "recall": 0.0, "accuracy": 1 - base},
        {"baseline": "always 'yes'", "roc_auc": 0.5, "pr_auc": base, "f1": f1_yes,
         "precision": base, "recall": 1.0, "accuracy": base},
        {"baseline": "random scores", "roc_auc": roc_auc_score(y_test, rnd),
         "pr_auc": average_precision_score(y_test, rnd), "f1": np.nan,
         "precision": base, "recall": np.nan, "accuracy": np.nan},
    ])


# ----------------------------------------------------------------------------
# Loading
# ----------------------------------------------------------------------------
def load_scores(scores_dir):
    found = {}
    for f in sorted(glob.glob(os.path.join(scores_dir, "scores_*.csv"))):
        m = FILE_PATTERN.match(os.path.basename(f))
        if not m:
            print(f"[warning] {os.path.basename(f)}: file name format not recognised, skipped")
            continue
        variant = "with_duration" if m["dur"] else "no_duration"
        found.setdefault((m["model"], variant), {})[m["split"]] = pd.read_csv(f)

    fit_times = {}
    ft_path = os.path.join(scores_dir, "fit_times.csv")
    if os.path.exists(ft_path):
        ft = pd.read_csv(ft_path)
        fit_times = {(r.model, r.variant): r.fit_time_s for r in ft.itertuples()}

    preds, y = {}, {}
    for key, d in found.items():
        if "validation" not in d or "test" not in d:
            print(f"[warning] {key}: validation or test file missing, skipped")
            continue
        for split in ("validation", "test"):
            yy = d[split]["y_true"].to_numpy().astype(int)
            if split in y:
                assert np.array_equal(y[split], yy), \
                    f"{key} ({split}): y_true differs from the other files -> a different data split may have been used"
            else:
                y[split] = yy
        preds[key] = {"p_val": d["validation"]["score"].to_numpy(float),
                      "p_test": d["test"]["score"].to_numpy(float),
                      "fit_time": fit_times.get(key, np.nan)}
    return preds, y.get("validation"), y.get("test")


# ----------------------------------------------------------------------------
# Plots
# ----------------------------------------------------------------------------
def plot_curves(variant, preds, y_test, out_dir):
    fig, ax = plt.subplots(1, 3, figsize=(17, 5))
    for (model, v), pr in preds.items():
        if v != variant:
            continue
        p = pr["p_test"]
        fpr, tpr, _ = roc_curve(y_test, p)
        ax[0].plot(fpr, tpr, label=f"{model} (AUC={roc_auc_score(y_test, p):.3f})")
        prec, rec, _ = precision_recall_curve(y_test, p)
        ax[1].plot(rec, prec, label=f"{model} (AP={average_precision_score(y_test, p):.3f})")
        x, g = cumulative_gain(y_test, p)
        ax[2].plot(x, g, label=model)
    ax[0].plot([0, 1], [0, 1], "k--", lw=0.8)
    ax[0].set(title="ROC", xlabel="False positive rate", ylabel="True positive rate")
    ax[1].axhline(y_test.mean(), color="k", ls="--", lw=0.8, label="random (base rate)")
    ax[1].set(title="Precision-Recall", xlabel="Recall", ylabel="Precision")
    ax[2].plot([0, 1], [0, 1], "k--", lw=0.8, label="random")
    ax[2].set(title="Cumulative gain (call priority)",
              xlabel="Fraction of clients called (ranked by score)", ylabel="Fraction of 'yes' captured")
    for a in ax:
        a.legend(fontsize=8)
        a.grid(alpha=0.3)
    fig.suptitle(VARIANT_LABEL[variant])
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"curves_{variant}.png"), dpi=150)
    plt.close(fig)


def plot_duration_effect(table, out_dir):
    piv = table.pivot(index="model", columns="variant", values="pr_auc")
    if not set(VARIANTS) <= set(piv.columns):
        return
    piv = piv[VARIANTS].sort_values("no_duration")
    ax = piv.plot(kind="barh", figsize=(8, 0.6 * len(piv) + 2.5))
    ax.set(xlabel="PR-AUC (test)", ylabel="", title="Effect of the duration variable")
    ax.legend([VARIANT_LABEL[v] for v in VARIANTS])
    ax.grid(alpha=0.3, axis="x")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "duration_effect.png"), dpi=150)
    plt.close()


def plot_confusion(variant, table, preds, y_test, out_dir):
    sub = table[table.variant == variant].sort_values("pr_auc", ascending=False).head(2)
    if sub.empty:
        return
    fig, ax = plt.subplots(1, len(sub), figsize=(5 * len(sub), 4.2), squeeze=False)
    for a, (_, row) in zip(ax[0], sub.iterrows()):
        yhat = (preds[(row.model, variant)]["p_test"] >= row.threshold).astype(int)
        cm = confusion_matrix(y_test, yhat)
        a.imshow(cm, cmap="Blues")
        for i in range(2):
            for j in range(2):
                a.text(j, i, cm[i, j], ha="center", va="center", fontsize=13)
        a.set(xticks=[0, 1], yticks=[0, 1], xticklabels=["no", "yes"], yticklabels=["no", "yes"],
              xlabel="Predicted", ylabel="Actual", title=f"{row.model} (threshold={row.threshold:.3f})")
    fig.suptitle(VARIANT_LABEL[variant])
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"confusion_{variant}.png"), dpi=150)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Demo (synthetic data) - only to test the pipeline
# ----------------------------------------------------------------------------
def make_demo(scores_dir):
    import time
    from sklearn.datasets import make_classification
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.tree import DecisionTreeClassifier

    X, y = make_classification(n_samples=8000, n_features=12, n_informative=5,
                               weights=[0.88, 0.12], flip_y=0.03, random_state=0)
    X = np.hstack([X, (y * 1.5 + np.random.RandomState(1).randn(len(y)))[:, None]])  # leaky feature, like "duration"
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(X, y, test_size=0.3, shuffle=False)
    X_val, X_te, y_val, y_te = train_test_split(X_tmp, y_tmp, test_size=0.5, shuffle=False)
    os.makedirs(scores_dir, exist_ok=True)
    models = {"logreg": lambda: LogisticRegression(max_iter=1000),
              "tree": lambda: DecisionTreeClassifier(max_depth=5, random_state=0),
              "rf": lambda: RandomForestClassifier(n_estimators=100, random_state=0)}
    ft_rows = []
    for name, mk in models.items():
        for variant in VARIANTS:
            cols = slice(None) if variant == "with_duration" else slice(0, -1)
            suffix = "_duration" if variant == "with_duration" else ""
            m = mk()
            t0 = time.time()
            m.fit(X_tr[:, cols], y_tr)
            ft_rows.append(dict(model=name, variant=variant, fit_time_s=time.time() - t0))
            for split, Xs, ys in (("validation", X_val, y_val), ("test", X_te, y_te)):
                pd.DataFrame({"y_true": ys, "score": m.predict_proba(Xs[:, cols])[:, 1]}).to_csv(
                    os.path.join(scores_dir, f"scores_{name}{suffix}_{split}.csv"), index=False)
    pd.DataFrame(ft_rows).to_csv(os.path.join(scores_dir, "fit_times.csv"), index=False)
    print(f"[demo] synthetic score files written to: {scores_dir}/")


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scores_dir", default="scores")
    ap.add_argument("--out_dir", default="results")
    ap.add_argument("--demo", action="store_true", help="test the pipeline on synthetic data")
    args = ap.parse_args()
    if args.demo:
        args.scores_dir, args.out_dir = "demo_scores", "demo_results"
        make_demo(args.scores_dir)

    os.makedirs(args.out_dir, exist_ok=True)
    preds, y_val, y_test = load_scores(args.scores_dir)
    if not preds:
        raise SystemExit(f"no scores_<model>_validation.csv / _test.csv found in {args.scores_dir}/")

    print(f"'yes' rate  validation: {y_val.mean():.3f} | test: {y_test.mean():.3f}  "
          f"(n_val={len(y_val)}, n_test={len(y_test)})")
    ratio = max(y_val.mean(), y_test.mean()) / min(y_val.mean(), y_test.mean())
    if ratio > 1.5:
        print(f"[WARNING] 'yes' rate differs strongly between validation and test (x{ratio:.1f}). "
              "PR-AUC values are not directly comparable across splits: look at pr_auc_over_base and roc_auc.")
    rows = [evaluate_one(m, v, y_val, y_test, pr) for (m, v), pr in preds.items()]
    table = pd.DataFrame(rows).sort_values(["variant", "pr_auc"], ascending=[True, False])
    if table["fit_time_s"].isna().all():
        table = table.drop(columns="fit_time_s")
    table.to_csv(os.path.join(args.out_dir, "results_table.csv"), index=False)
    bt = budget_table(preds, y_test)
    bt.to_csv(os.path.join(args.out_dir, "budget_table.csv"), index=False)
    bl = baseline_table(y_test)
    bl.to_csv(os.path.join(args.out_dir, "baselines.csv"), index=False)
    with pd.option_context("display.width", 220, "display.max_columns", 20):
        print(table.round(3).to_string(index=False))
        print("\nBaselines (test):")
        print(bl.round(3).to_string(index=False))
        print("\nCall-budget table (top x% of clients by score):")
        print(bt.round(3).to_string(index=False))

    for v in VARIANTS:
        if any(k[1] == v for k in preds):
            plot_curves(v, preds, y_test, args.out_dir)
            plot_confusion(v, table, preds, y_test, args.out_dir)
    plot_duration_effect(table, args.out_dir)
    print(f"\nTables and plots written to: {args.out_dir}/")


if __name__ == "__main__":
    main()